//
//  AppModel.swift
//  Hello
//
//  Created by iGuest on 4/19/16.
//  Copyright © 2016 iGuest. All rights reserved.
//

import Foundation

class ButtonClicks {
    var number : Int = 0
}