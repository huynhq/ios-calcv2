//
//  ViewController.swift
//  Hello
//
//  Created by iGuest on 4/19/16.
//  Copyright © 2016 iGuest. All rights reserved.
//

import UIKit

class MainController: UIViewController {
    
    let model : ButtonClicks = ButtonClicks()

    @IBOutlet weak var textLabel: UILabel!
    
    @IBAction func buttonPressed(sender: UIButton) {
        model.number = model.number + 1
        
        NSLog("Button was pressed for the \(model.number)th time!")
        
        textLabel.text = "\(model.number)!"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

